/*******************************************************************************
  Main Source File

  Company:
    Microchip Technology Inc.

  File Name:
    main.c

  Summary:
    This file contains the "main" function for a project.

  Description:
    This file contains the "main" function for a project.  The
    "main" function calls the "SYS_Initialize" function to initialize the state
    machines of all modules in the system
 *******************************************************************************/

// *****************************************************************************
// *****************************************************************************
// Section: Included Files
// *****************************************************************************
// *****************************************************************************

#include <stddef.h>                     // Defines NULL
#include <stdbool.h>                    // Defines true
#include <stdlib.h>                     // Defines EXIT_FAILURE
#include "definitions.h"                // SYS function prototypes
#define SYS_FREQ 200000000              // Running at 200 MHz


// Code added - string definition
uint8_t buffer[] = "Hello World!\r\n";

// *****************************************************************************
// *****************************************************************************
// Section: Main Entry Point
// *****************************************************************************
// *****************************************************************************

void delay_us(unsigned int us) {
    // convert microseconds into how many clock ticks it will take
    us *= SYS_FREQ / 1000000 / 2; // core timer updates every 2 ticks
    _CP0_SET_COUNT(0); // set core timer count to 0
    while(us > _CP0_GET_COUNT()); // wait until core timer reaches number we calculated
}

void delay_ms(int ms) {
    delay_us(ms * 1000);
}

int main ( void ) {
    /* Initialize all modules */
    SYS_Initialize ( NULL );

    // Code added - Application logic to send the string
    UART6_Write(&buffer[0], sizeof(buffer));
    
    // Code added - LED Test, turn on LED1
    TRISH = 0; // Configures 16-pins from RH0 to RH15 to be output 
    // 0 is output, 1 is input
    // PORTH = 1 << 2 | 1 << 3 | 1 << 1; // // Drives the 16-pins from RH0 to RH15 to be high
    // RH0 = 1
    // RH1 = 3
    // RH2 = 2
    
    while ( true ) {
        /* Maintain state machines of all polled MPLAB Harmony modules. */
        SYS_Tasks ( );
        PORTH = 0 << 1 | 1 << 2 | 0 << 3 | 0 << 4 | 0 << 5 | 0 << 6 | 0 << 7;
        delay_ms(50);
        PORTH = 1 << 1 | 1 << 2 | 0 << 3 | 0 << 4 | 0 << 5 | 0 << 6 | 0 << 7;
        delay_ms(50);
        PORTH = 1 << 1 | 1 << 2 | 1 << 3 | 0 << 4 | 0 << 5 | 0 << 6 | 0 << 7;
        delay_ms(50);
        PORTH = 1 << 1 | 1 << 2 | 1 << 3 | 1 << 4 | 0 << 5 | 0 << 6 | 0 << 7;
        delay_ms(50);
        PORTH = 0 << 1 | 1 << 2 | 1 << 3 | 1 << 4 | 1 << 5 | 0 << 6 | 0 << 7;
        delay_ms(50);
        PORTH = 0 << 1 | 1 << 2 | 0 << 3 | 1 << 4 | 1 << 5 | 1 << 6 | 0 << 7;
        delay_ms(50);
        PORTH = 0 << 1 | 1 << 2 | 0 << 3 | 0 << 4 | 1 << 5 | 1 << 6 | 1 << 7;
        delay_ms(50);
        PORTH = 0 << 1 | 1 << 2 | 0 << 3 | 0 << 4 | 0 << 5 | 1 << 6 | 1 << 7;
        delay_ms(50);
        PORTH = 0 << 1 | 1 << 2 | 0 << 3 | 0 << 4 | 0 << 5 | 0 << 6 | 1 << 7;
        delay_ms(50);
        PORTH = 0 << 1 | 1 << 2 | 0 << 3 | 0 << 4 | 0 << 5 | 0 << 6 | 0 << 7;
        delay_ms(50);
     }

    /* Execution should not come here during normal operation */

    return ( EXIT_FAILURE );
    // return(0);
}


/*******************************************************************************
 End of File
*/

