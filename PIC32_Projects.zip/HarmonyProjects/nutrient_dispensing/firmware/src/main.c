/*******************************************************************************
  Main Source File

  Company:
    Microchip Technology Inc.

  File Name:
    main.c

  Summary:
    This file contains the "main" function for a project.

  Description:
    This file contains the "main" function for a project.  The
    "main" function calls the "SYS_Initialize" function to initialize the state
    machines of all modules in the system
 *******************************************************************************/

// *****************************************************************************
// *****************************************************************************
// Section: Included Files
// *****************************************************************************
// *****************************************************************************

#include <stddef.h>                     // Defines NULL
#include <stdbool.h>                    // Defines true
#include <stdlib.h>                     // Defines EXIT_FAILURE
#include "definitions.h"                // SYS function prototypes
#define SYS_FREQ 200000000              // Running at 200 MHz


// *****************************************************************************
// *****************************************************************************
// Section: Main Entry Point
// *****************************************************************************
// *****************************************************************************

// delay functions
void delay_us(unsigned int us) {
    // convert microseconds into how many clock ticks it will take
    us *= SYS_FREQ / 1000000 / 2; // core timer updates every 2 ticks
    _CP0_SET_COUNT(0); // set core timer count to 0
    while(us > _CP0_GET_COUNT()); // wait until core timer reaches number we calculated
}

void delay_ms(int ms) {
    delay_us(ms * 1000);
}

int main ( void ) {
    
    TRISJbits.TRISJ10 = 0; // RJ10 is output led
    TRISHbits.TRISH12 = 1; // RJ12 is input button
    
    PORTJbits.RJ10 = 0; // RJ10 led is off
    
    while(1) {
        if(PORTJbits.RJ12 == 1) {
            PORTJbits.RJ10 = 1;
        }
        else {
            PORTJbits.RJ10 = 0;
        }
    }
    
    /* Execution should not come here during normal operation */

    return ( EXIT_FAILURE );
}


/*******************************************************************************
 End of File
*/

