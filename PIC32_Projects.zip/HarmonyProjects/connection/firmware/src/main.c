/*******************************************************************************
  Main Source File

  Company:
    Microchip Technology Inc.

  File Name:
    main.c

  Summary:
    This file contains UART and SPI connection for PIC32MX150F128B

  Description:
    This file contains the functions to establish UART and SPI connection for
    PIC32MX150F128B and will show reading and writing from print statements
 *******************************************************************************/

// *****************************************************************************
// *****************************************************************************
// Section: Included Files
// *****************************************************************************
// *****************************************************************************

#include <stddef.h>                     // Defines NULL
#include <stdbool.h>                    // Defines true
#include <stdlib.h>                     // Defines EXIT_FAILURE
#include "definitions.h"                // SYS function prototypes
#include <stdio.h>
#define SYS_FREQ = 48000000             // SYS frequency 48 MHz
#define BAUDRATE 115200                 // baud rate at 115200 Hz

// *****************************************************************************
// *****************************************************************************
// Section: Main Entry Point
// *****************************************************************************
// *****************************************************************************

// delay function in microseconds
/*
void delay_us(unsigned int us) {
    // convert microseconds into how many clock ticks it will take
    us *= SYS_FREQ / 1000000 / 2; // core timer updates every 2 ticks
    _CP0_SET_COUNT(0); // set core timer count to 0
    while(us > _CP0_GET_COUNT()); // wait until core timer reaches number we calculated
}
 
// delay function in milliseconds
void delay_ms(int ms) {
    delay_us(ms * 1000);
}
*/

/*
// function to flash on board led for 1 second
void onboardled() {
    // flashes on board led every second
    PORTAbits.RA0 = 1;
    delay_ms(1000);
    PORTAbits.RA0 = 0;
    delay_ms(1000);
}
*/

void UART_Init() {
    int pbClk;
    
    pbClk = 48000000 / 2;
 
    U1MODE = 0; // set UART 1 off prior to setting it up
    U1MODEbits.BRGH = 0; // want standard speed
    U1BRG = pbClk / (16 * 115200) - 1;
    U1STA = 0; // disable TX and RX pins, clear all flags
    U1STAbits.UTXEN = 1; // enable TX pin
    U1STAbits.URXEN = 1; // enable RX pin
    U1MODEbits.PDSEL = 0;
    U1MODEbits.STSEL = 0;
    U1MODEbits.ON = 1;
}

void _mon_putc (char c) {
    while(U1STAbits.UTXBF);
    U1TXREG = c;
}

int main ( void )
{
    /* Initialize all modules */
    SYS_Initialize ( NULL );
    
    int cnt;
    
    // set all ports to be digital, not analog
    ANSELA = 0;
    ANSELB = 0;
    
    // initializing RPB2 = U1RX 
    U1RXR = 0b0100;
    TRISBbits.TRISB2 = 1; // make RPB2/RB2 an input
    RPB3R = 0b0001; // make RPB3/RB3 an output, RPB3 = U1TX
        
    // set on board LED as output
    TRISAbits.TRISA0 = 0;
    
    UART_Init();
    
    cnt = 0;
    
    while ( true )
    {
        /* Maintain state machines of all polled MPLAB Harmony modules. */
        SYS_Tasks ( );
        printf("Counter value is %d\n", cnt);
		//delay_ms(1000); // Delay 1 second
		cnt++;
    }

    /* Execution should not come here during normal operation */

    return ( EXIT_FAILURE );
}


/*******************************************************************************
 End of File
*/

