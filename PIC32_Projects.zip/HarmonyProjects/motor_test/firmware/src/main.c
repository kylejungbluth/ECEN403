/*******************************************************************************
  Main Source File

  Company:
    Microchip Technology Inc.

  File Name:
    main.c

  Summary:
    This file contains the servo motor direction

  Description:
    This file contains the function for servo motor control in 0, 90, and 180 direction
    along with corresponding LEDs to show user which direction it's currently facing
 *******************************************************************************/

// *****************************************************************************
// *****************************************************************************
// Section: Included Files
// *****************************************************************************
// *****************************************************************************

#include <stddef.h>                     // Defines NULL
#include <stdbool.h>                    // Defines true
#include <stdlib.h>                     // Defines EXIT_FAILURE
#include "definitions.h"                // SYS function prototypes
#define SYS_FREQ 200000000              // Running at 200 MHz


// *****************************************************************************
// *****************************************************************************
// Section: Main Entry Point
// *****************************************************************************
// *****************************************************************************

// delay functions
void delay_us(unsigned int us) {
    // convert microseconds into how many clock ticks it will take
    us *= SYS_FREQ / 1000000 / 2; // core timer updates every 2 ticks
    _CP0_SET_COUNT(0); // set core timer count to 0
    while(us > _CP0_GET_COUNT()); // wait until core timer reaches number we calculated
}

void delay_ms(int ms) {
    delay_us(ms * 1000);
}

void servoRotate0() { // 0 degree
    unsigned int i;
    PORTHbits.RH0 = 1; // red led on, RH0
    for(i = 0; i < 50; i++) {
        PORTJ = 1 << 10; // | 1 << 12;
        delay_us(800);
        PORTJ= 0 << 10; // | 0 << 12;
        delay_us(19200);
    }
    PORTHbits.RH0 = 0; // red led off
}

void servoRotate90() { // 90 degree
    unsigned int i;
    PORTHbits.RH1 = 1; // yellow led on, RH1
    for(i = 0; i < 50; i++) {
        
        PORTJ= 1 << 10 | 1 << 12;
        delay_us(1500);
        PORTJ= 0 << 10 | 0 << 12;
        delay_us(18500);
    }
    PORTHbits.RH1 = 0; // yellow led off
}

void servoRotate180() { // 180 degrees
    unsigned int i;
    PORTHbits.RH3 = 1; // blue led on, RH3 
    for(i = 0; i < 50; i++) {
        PORTJ= 1 << 10 | 1 << 12;
        delay_us(2200);
        PORTJ= 0 << 10 | 0 << 12;
        delay_us(17800);
    }
    PORTHbits.RH3 = 0; // blue led off
}

int main ( void )
{
    /* Initialize all modules */
    SYS_Initialize ( NULL );
    
    // turn on on-board LED
    TRISH = 0; 
    PORTHbits.RH2 = 1;
    
    TRISJbits.TRISJ10 = 0; // use port RJ10 for motor output
            
    while ( true )
    {
        /* Maintain state machines of all polled MPLAB Harmony modules. */
        SYS_Tasks ( );
        // red led should turn on
        servoRotate0();
        delay_ms(2500);
        
        // yellow led should turn on
        servoRotate90();
        delay_ms(2500);
        
        // blue led should turn on
        servoRotate180();
        delay_ms(2500);
    }

    /* Execution should not come here during normal operation */

    return ( EXIT_FAILURE );
}


/*******************************************************************************
 End of File
*/

